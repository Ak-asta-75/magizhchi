package mew;
public class Singly 
{
    public static Node head;
    public void insertAtEnd(int data)
    {
        Node newNode = new Node(data);
        if (head == null)
        {
            head = newNode;
            return;
        }
        Node temp =head;
        while (temp.next != null)
        {
            temp = temp.next;
        }
        temp.next = newNode;
    }
    public void insertAtBegin(int data)
    {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }
    public void display()
    {
        if(head == null)
        {
            return;
        }
        Node temp = head;
        while(temp != null)
        {
            System.out.println(temp.data + "=>");
            temp = temp.next;
        }
        System.out.println("Null");
    }
    public static void main(String[] args) {
        Singly si = new Singly();
        si.insertAtBegin(30);
        si.insertAtBegin(20);
        si.insertAtBegin(10);
        si.insertAtEnd(40);
    }
}
