package enums3;
import java.util.Scanner;
public class OrderTrackingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;

        while (choice != 3) {
            System.out.println("--- MENU ---");
            System.out.println("1. Show Order Status");
            System.out.println("2. Check if Order is Completed");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            if (choice == 1 || choice == 2) {
                System.out.print("Select Status (1-PLACED, 2-SHIPPED, 3-DELIVERED, 4-CANCELLED): ");
                int statusIndex = scanner.nextInt();
                OrderStatus status = OrderStatus.values()[statusIndex - 1];

                if (choice == 1) {
                    System.out.println("Current Status: " + status);
                } else {
                    if (status == OrderStatus.DELIVERED) {
                        System.out.println("Order is COMPLETED.");
                    } else if (status == OrderStatus.CANCELLED) {
                        System.out.println("Order is CANCELLED (Not completed).");
                    } else {
                        System.out.println("Order is IN PROGRESS (Not completed).");
                    }
                }
            }
        }
        System.out.println("Exited program.");
        scanner.close();
    }
}