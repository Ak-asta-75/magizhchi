package enums3;
public enum OrderStatus {
    PLACED,
    SHIPPED,
    DELIVERED,
    CANCELLED;
}
