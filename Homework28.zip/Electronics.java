package Homework28;

public class Electronics extends Product {
    int warrantyMonths;

    public Electronics(String name, double price, int warrantyMonths) {
        super(name, price);
        this.warrantyMonths = warrantyMonths;
    }

    public void displayElectronics() {
        displayProduct();
        System.out.println("Warranty: " + warrantyMonths + " months");
    }
}
