package Homework28;
public class Homework28 {
    public static void main(String[] args) {
        Electronics laptop = new Electronics("Gaming Laptop", 1299.99, 24);
        Clothing jacket = new Clothing("Denim Jacket", 79.50, "L", "100% Cotton");

        System.out.println("=== Electronics Details ===");
        laptop.displayElectronics();

        System.out.println("=== Clothing Details ===");
        jacket.displayClothing();
    }
}
