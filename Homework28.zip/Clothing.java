package Homework28;
public class Clothing extends Product {
    String size;
    String fabric;

    public Clothing(String name, double price, String size, String fabric) {
        super(name, price);
        this.size = size;
        this.fabric = fabric;
    }

    public void displayClothing() {
        displayProduct();
        System.out.println("Size: " + size);
        System.out.println("Fabric: " + fabric);
    }
}
