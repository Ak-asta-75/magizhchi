package enums;
public enum Signal {
    RED,
    GREEN,
    YELLOW;
}
