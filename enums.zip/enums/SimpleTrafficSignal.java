package enums;
import java.util.Scanner;
public class SimpleTrafficSignal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;

        while (choice != 3) {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Show Signal Meaning");
            System.out.println("2. Check Stop or Go");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            if (choice == 1 || choice == 2) {
                System.out.print("Select Signal (1-RED, 2-YELLOW, 3-GREEN): ");
                int signalChoice = scanner.nextInt();
                Signal signal = Signal.values()[signalChoice - 1];

                if (choice == 1) {
                    if (signal == Signal.RED) System.out.println("Meaning: Vehicles must stop.");
                    else if (signal == Signal.YELLOW) System.out.println("Meaning: Prepare to stop.");
                    else System.out.println("Meaning: Safe to go.");
                } else {
                    if (signal == Signal.RED) System.out.println("Action: STOP");
                    else if (signal == Signal.YELLOW) System.out.println("Action: SLOW DOWN");
                    else System.out.println("Action: GO");
                }
            }
        }
        System.out.println("Exited program.");
        scanner.close();
    }
}