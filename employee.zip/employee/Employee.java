package j59;

class Employee {

    int id;
    String name;
    String department;
    double basicSalary;

    public Employee(int id, String name, String department, double basicSalary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.basicSalary = basicSalary;
    }

    public double calculateNetSalary() {
        double hra = 0.20 * basicSalary;
        double da = 0.10 * basicSalary;
        double pf = 0.05 * basicSalary;
        return basicSalary + hra + da - pf;
    }

    public double display() {
        System.out.println("ID : " + id);
        System.out.println("Name : " + name);
        System.out.println("Dept : " + department);
        System.out.println("Basic Salary : " + basicSalary);
        return 0;
    }
}
