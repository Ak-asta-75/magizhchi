package j59;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ArrayList<Employee> list = new ArrayList<>();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add");
            System.out.println("2.View All");
            System.out.println("3.Search");
            System.out.println("4.Update Salary");
            System.out.println("5.Net Salary");
            System.out.println("6.Delete");
            System.out.println("7.Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("Enter ID: ");
                int id = sc.nextInt();
                sc.nextLine(); 

                boolean exists = false;
                for (Employee e : list) {
                    if (e.id == id) {
                        exists = true;
                        break;
                    }
                }
                if (exists) {
                    System.out.println("ID already exists!");
                    continue;
                }

                System.out.print("Enter Name: ");
                String name = sc.nextLine();
                System.out.print("Enter Department: ");
                String dept = sc.nextLine();
                System.out.print("Enter Basic Salary: ");
                double salary = sc.nextDouble();

                list.add(new Employee(id, name, dept, salary));
                System.out.println("Employee added!");

            } else if (choice == 2) {
                if (list.isEmpty()) {
                    System.out.println("No records found.");
                } else {
                    for (Employee e : list) {
                        e.display();
                    }
                }

            } else if (choice == 3) {
                System.out.print("Enter ID to search: ");
                int id = sc.nextInt();
                boolean found = false;
                for (Employee e : list) {
                    if (e.id == id) {
                        e.display();
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    System.out.println("Employee not found!");
                }

            } else if (choice == 4) {
                System.out.print("Enter ID to update: ");
                int id = sc.nextInt();
                boolean found = false;
                for (Employee e : list) {
                    if (e.id == id) {
                        System.out.print("Enter New Basic Salary: ");
                        e.basicSalary = sc.nextDouble();
                        System.out.println("Salary updated!");
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    System.out.println("Employee not found!");
                }

            } else if (choice == 5) {
                System.out.print("Enter ID: ");
                int id = sc.nextInt();
                boolean found = false;
                for (Employee e : list) {
                    if (e.id == id) {
                        System.out.println("Net Salary: " + e.calculateNetSalary());
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    System.out.println("Employee not found!");
                }

            } else if (choice == 6) {
                System.out.print("Enter ID to delete: ");
                int id = sc.nextInt();
                boolean found = false;
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).id == id) {
                        list.remove(i);
                        System.out.println("Employee deleted!");
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    System.out.println("Employee not found!");
                }

            } else if (choice == 7) {
                System.out.println("Exiting application.");
                break;
            } else {
                System.out.println("Invalid choice!");
            }
        }
        sc.close();
    }
}
