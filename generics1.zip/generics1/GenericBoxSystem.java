package generics1;
import java.util.Scanner;

public class GenericBoxSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Box<Object> box = new Box<>();
        int choice = 0;

        while (choice != 4) {
            System.out.println("--- MENU ---");
            System.out.println("1. Store Integer");
            System.out.println("2. Store String");
            System.out.println("3. Display Value");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            if (choice == 1) {
                System.out.print("Enter an integer: ");
                box.set(scanner.nextInt());
                System.out.println("Integer stored.");
            } else if (choice == 2) {
                System.out.print("Enter a string: ");
                box.set(scanner.next());
                System.out.println("String stored.");
            } else if (choice == 3) {
                System.out.println("Stored Value: " + box.get());
            }
        }
        System.out.println("Exited program.");
        scanner.close();
    }
}