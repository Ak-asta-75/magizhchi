package summa;
public class CityBus extends Transport {
    public CityBus(int passengerId, String passengerName, String fromCity, String toCity, double distance) {
        super(passengerId, passengerName, fromCity, toCity, distance);
    }

    @Override
    public void calculateFare() {
        this.fare = this.distance * 5;
    }
}
