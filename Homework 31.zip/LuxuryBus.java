
package summa;
public class LuxuryBus extends Transport {
    public LuxuryBus(int passengerId, String passengerName, String fromCity, String toCity, double distance) {
        super(passengerId, passengerName, fromCity, toCity, distance);
    }

    @Override
    public void calculateFare() {
        this.fare = (this.distance * 10) + 200;
    }
}
