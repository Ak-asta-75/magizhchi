package summa;
// File: Main.java
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Transport currentBooking = null; // Stores current passenger ticket
        int choice = 0;

        while (choice != 5) {
            System.out.println("---- TRANSPORT MANAGEMENT SYSTEM ----");
            System.out.println("1. City Bus Booking");
            System.out.println("2. Luxury Bus Booking");
            System.out.println("3. Calculate Fare");
            System.out.println("4. Display Ticket");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            choice = scanner.nextInt();

            if (choice == 1 || choice == 2) {
                System.out.print("Enter Passenger ID: ");
                int id = scanner.nextInt();
                scanner.nextLine(); // clear input buffer

                System.out.print("Enter Passenger Name: ");
                String name = scanner.nextLine();

                // Display routes
                System.out.println("Select Route:");
                System.out.println("1. Chennai -> Bangalore");
                System.out.println("2. Chennai -> Coimbatore");
                System.out.println("3. Chennai -> Madurai");
                System.out.println("4. Chennai -> Trichy");
                System.out.println("5. Chennai -> Salem");
                System.out.print("Enter route choice: ");
                int routeChoice = scanner.nextInt();

                String fromCity = "Chennai";
                String toCity = "";
                double distance = 0;

                // Simple if-else condition for choosing route
                if (routeChoice == 1) {
                    toCity = "Bangalore";
                    distance = 350;
                } else if (routeChoice == 2) {
                    toCity = "Coimbatore";
                    distance = 500;
                } else if (routeChoice == 3) {
                    toCity = "Madurai";
                    distance = 460;
                } else if (routeChoice == 4) {
                    toCity = "Trichy";
                    distance = 330;
                } else if (routeChoice == 5) {
                    toCity = "Salem";
                    distance = 340;
                } else {
                    System.out.println("Invalid route selection!");
                }

                // Check if route was valid before creating booking
                if (distance > 0) {
                    if (choice == 1) {
                        currentBooking = new CityBus(id, name, fromCity, toCity, distance);
                    } else if (choice == 2) {
                        currentBooking = new LuxuryBus(id, name, fromCity, toCity, distance);
                    }
                    System.out.println("Ticket Booked Successfully");
                }

            } else if (choice == 3) {
                if (currentBooking != null) {
                    currentBooking.calculateFare();
                    System.out.println("Fare Calculated Successfully");
                } else {
                    System.out.println("Please book a ticket first!");
                }

            } else if (choice == 4) {
                if (currentBooking != null) {
                    currentBooking.displayTicket();
                } else {
                    System.out.println("Please book a ticket first!");
                }

            } else if (choice == 5) {
                System.out.println("Thank you for using the Transport Management System!");

            } else {
                System.out.println("Invalid option! Please enter a number between 1 and 5.");
            }
        }

        scanner.close();
    }
}