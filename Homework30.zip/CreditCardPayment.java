
package Interface;

public class CreditCardPayment implements Payment {
    String cardNumber;

    public CreditCardPayment(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    @Override
    public void pay(double amount) {
 
        System.out.println("[Credit Card] Paid $" + amount + " using Card (" + cardNumber + ")");
    }
}
