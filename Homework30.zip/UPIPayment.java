
package Interface;

public class UPIPayment implements Payment {
    String upiId;

    public UPIPayment(String upiId) {
        this.upiId = upiId;
    }

    @Override
    public void pay(double amount) {
        
        System.out.println("[UPI] Paid $" + amount + " successfully using UPI ID (" + upiId + ")");
    }
}