
package Interface;

public class Main {
    public static void main(String[] args) {
       
        double amount = 250.50;

        System.out.println("--- Processing Payments ---");
       
        Payment creditCard = new CreditCardPayment("1234567890123456");
        Payment upi = new UPIPayment("user@okbank");

        creditCard.pay(amount);
        upi.pay(amount);
    }
}