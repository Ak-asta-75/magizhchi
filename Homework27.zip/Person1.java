package Homework27;
public class Person1 {
    String name;
    public Person1(String name){
        this.name = name;
    }
    public void displayP() {
        System.out.println("Name : " + name);
    }
}
