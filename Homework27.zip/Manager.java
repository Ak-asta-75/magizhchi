package Homework27;
public class Manager extends Employ {
    String department;

    public Manager(String name, double salary, String department) {
        super(name, salary);
        this.department = department;
    }

    public void displayManager() {
        displayE();
        System.out.println("Department: " + department);
    }
}
