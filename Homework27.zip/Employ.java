package Homework27;
public class Employ extends Person1 {
    double salary;
    public Employ (String name, double salary) {
        super(name);
        this.salary = salary;
    }
    public void displayE(){
        displayP();
        System.out.println("Salary : " + salary);
    }
}
