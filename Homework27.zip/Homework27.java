package Homework27;
public class Homework27 
{
    public static void main(String[] args) {
        Manager mgr = new Manager("Abishek Kanna", 95000.0, "Engineering");
        System.out.println("=== Manager Details ===");
        mgr.displayManager();
    }
}    

