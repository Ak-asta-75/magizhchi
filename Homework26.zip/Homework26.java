package Homework;
public class Homework26 
{
    public static void main(String[] args) {
        Student student = new Student("Abishek Kanna", 20, 101, 88.5);
        System.out.println("=== Student Details ===");
        student.displayStudentDetails();
    }
}
