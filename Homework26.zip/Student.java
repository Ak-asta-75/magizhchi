package Homework;
public class Student extends Person
{
    private int rollNumber;
    private double marks;

    public Student(String name, int age, int rollNumber, double marks) {
        super(name, age); // Call base class constructor
        this.rollNumber = rollNumber;
        this.marks = marks;
    }

    public void displayStudentDetails() {
        displayPersonDetails(); // Display Person info
        System.out.println("Roll Number: " + rollNumber);
        System.out.println("Marks: " + marks);
    }
}
