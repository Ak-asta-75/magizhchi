package enums2;
import java.util.Scanner;
public class WeekdaySystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;

        while (choice != 4) {
            System.out.println("--- MENU ---");
            System.out.println("1. Check if day is Working Day");
            System.out.println("2. Check if day is Weekend");
            System.out.println("3. Display All Days");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            if (choice == 1 || choice == 2) {
                System.out.print("Select Day (1-MON, 2-TUE, 3-WED, 4-THU, 5-FRI, 6-SAT, 7-SUN): ");
                int dayIndex = scanner.nextInt();
                Day day = Day.values()[dayIndex - 1];

                boolean isWeekend = (day == Day.SATURDAY || day == Day.SUNDAY);

                if (choice == 1) {
                    if (!isWeekend) {
                        System.out.println(day + " is a Working Day.");
                    } else {
                        System.out.println(day + " is NOT a Working Day.");
                    }
                } else {
                    if (isWeekend) {
                        System.out.println(day + " is a Weekend!");
                    } else {
                        System.out.println(day + " is NOT a Weekend.");
                    }
                }
            } else if (choice == 3) {
                System.out.println("Days of the Week:");
                for (Day d : Day.values()) {
                    System.out.println("- " + d);
                }
            }
        }
        System.out.println("Exited program.");
        scanner.close();
    }
}