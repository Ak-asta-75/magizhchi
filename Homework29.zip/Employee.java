package Abstract;
abstract class Employee {
    String name;

    public Employee(String name) {
        this.name = name;
    }

    // Abstract method to be implemented by subclasses
    public abstract double calculateSalary();

    // Concrete method common to all subclasses
    public void displayEmployee() {
        System.out.println("-----------------------------------");
        System.out.println("Employee Name: " + name);
        System.out.printf("Calculated Salary: $%.2f%n", calculateSalary());
    }
}

