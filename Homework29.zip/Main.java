
package Abstract;

public class Main {
    public static void main(String[] args) {
        // Instantiate a Full-Time Employee
        Employee fullTime = new FullTimeEmployee("Abishek", 5500.00);

        // Instantiate a Part-Time Employee (e.g., 80 hours @ $25/hr)
        Employee partTime = new PartTimeEmployee("Haariz", 80, 25.00);

        // Display details and calculated salaries
        fullTime.displayEmployee();
        partTime.displayEmployee();
        System.out.println("-----------------------------------");
    }
}
