package singlyString;
public class SinglyString  
{
    public static Main head;
    public void insertAtEnd(String data)
    {
        Main newNode = new Main(data);
        if (head == null)
        {
            head = newNode;
            return;
        }
        Main temp =head;
        while (temp.next != null)
        {
            temp = temp.next;
        }
        temp.next = newNode;
    }
    public void insertAtBegin(String data)
    {
        Main newNode = new Main(data);
        newNode.next = head;
        head = newNode;
    }
    public void display()
    {
        if(head == null)
        {
            return;
        }
        Main temp = head;
        while(temp != null)
        {
            System.out.println(temp.data + "=>");
            temp = temp.next;
        }
        System.out.println("Null");
    }
    public static void main(String[] args) {
        SinglyString si = new SinglyString();
        si.insertAtBegin("Ravi");
        si.insertAtBegin("Kumaar");
        si.insertAtBegin("Arun");
        si.insertAtEnd("Ajay");
    }
}

