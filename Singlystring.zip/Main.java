
package singlyString;

public class Main 
{
    String data;
    Main next;
    
    Main(String data)
    {
        this.data = data;
        this.next = null;
    }
}

